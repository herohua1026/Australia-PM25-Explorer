Australian calibrated PM2.5 research product, ACAG v16.6 audited, M7.
Units: micrograms per cubic metre. Fixed 2021 SA2 boundaries.
Physical-area averages, not population-weighted. Annual values are equal means of exactly 12 months.
Historical estimates, not live readings or AQI. Validation RMSE is not an individual confidence interval.
Source ACAG: https://www.satpm.org/v6-gl-03
Monitoring: NAPMD https://doi.org/10.17605/OSF.IO/JXD98
Publisher citation and redistribution terms must be confirmed before public release.
Source CSV SHA256: eea061b943ae6de8816c6c6895dfb62815f44ebfbff3afaae54dd7de69b90830
